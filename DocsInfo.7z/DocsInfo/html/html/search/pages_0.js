var searchData=
[
  ['capi_0',['CAPI',['../md__c_1_2xampp_2htdocs_2_c_a_p_i_2_r_e_a_d_m_e.html',1,'']]]
];
